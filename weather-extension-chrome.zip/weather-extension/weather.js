import axios from "axios";

// https://api.open-meteo.com/v1/forecast?latitude=52.52&longitude=13.41&daily=weathercode,temperature_2m_max,temperature_2m_min&current_weather=true&timeformat=unixtime&timezone=Asia%2FKolkata

const getWeather = (lon, lat, timeZone) => {
  console.log("Inside weather.js");

  axios
    .get(
      "https://api.open-meteo.com/v1/forecast?daily=weathercode,temperature_2m_max,temperature_2m_min&current_weather=true&timeformat=unixtime",
      {
        params: {
          latitude: lat,
          longitude: lon,
          timezone: timeZone,
        },
      }
    )
    .then(({ data }) => {
      return { current: getCurrent(data), daily: getDaily(data) };
    });
};

const getCurrent = ({ current_weather, daily }) => {
  const { temperature: currentTemp, weatherCode: iconCode } = current_weather;

  const { temperature_2m_max: maxTemp, temperature_2m_min: minTemp } = daily;

  return {
    currentTemp: Math.round(currentTemp),
    maxTemp: Math.round(maxTemp),
    minTemp: Math.round(minTemp),
    iconCode,
  };
};

const getDaily = ({ data }) => {
  return { dailyTemp: data.daily };
};

// export default getWeather;
